# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['splunk_eventgen',
 'splunk_eventgen.eventgen_api_server',
 'splunk_eventgen.lib',
 'splunk_eventgen.lib.logging_config',
 'splunk_eventgen.lib.plugins',
 'splunk_eventgen.lib.plugins.generator',
 'splunk_eventgen.lib.plugins.output',
 'splunk_eventgen.lib.plugins.rater',
 'splunk_eventgen.splunk_app.bin',
 'splunk_eventgen.splunk_app.lib',
 'splunk_eventgen.splunk_app.lib.mod_input']

package_data = \
{'': ['*'],
 'splunk_eventgen': ['README/*',
                     'default/*',
                     'logs/*',
                     'samples/*',
                     'splunk_app/*',
                     'splunk_app/README/*',
                     'splunk_app/default/*',
                     'splunk_app/default/data/ui/nav/*',
                     'splunk_app/metadata/*',
                     'splunk_app/static/*']}

install_requires = \
['Flask>=1.0.3,<2.0.0',
 'PyYAML>=5.3.1,<6.0.0',
 'boto3==1.12.45',
 'cryptography==36.0.2',
 'docker>=3.7.3,<4.0.0',
 'httplib2>=0.17.2,<0.18.0',
 'importlib-metadata>=1.0.0,<2.0.0',
 'jinja2==2.10.3',
 'lxml>=4.3.5,<5.0.0',
 'markupsafe==2.0.1',
 'pyOpenSSL>=19.1.0,<20.0.0',
 'redis==3.3.10',
 'requests-futures==1.0.0',
 'requests>=2.18.4,<3.0.0',
 'ujson>=2.0.3,<3.0.0',
 'urllib3==1.24.2']

entry_points = \
{'console_scripts': ['splunk_eventgen = splunk_eventgen.__main__:main']}

setup_kwargs = {
    'name': 'splunk-eventgen',
    'version': '7.2.1',
    'description': 'Splunk Event Generator to produce real-time, representative data',
    'long_description': '# Splunk Event Generator (Eventgen)\n\n### Status\n[![CircleCI](https://circleci.com/gh/splunk/eventgen/tree/develop.svg?style=svg&circle-token=15e952a75e368102d8cebc6d9445af87e6c7d57e)](https://circleci.com/gh/splunk/eventgen/tree/develop)\n\n### Introduction\n\nSplunk Event Generator is a utility that helps users easily build real-time event generators.\nThe current maintainers of this project are Brian Bingham (bbingham@splunk.com), Tony Lee (tonyl@splunk.com), and Jack Meixensperger (jackm@splunk.com).\n\nThe goals of this project:\n\n* Eliminate the need for hand-coded event generators in Splunk apps\n* Allow for portability of event generators between applications and allow templates to be quickly adapted between use cases\n* Allow every type of events or transactions to be modeled inside Eventgen\n\n### Downloading a Splunk Eventgen App\n\nPlease go to [splunkbase-Eventgen](https://splunkbase.splunk.com/app/1924/#/overview)\n\n### Documentation\n\nDocumentation is hosted at [Eventgen Documentation](http://splunk.github.io/eventgen/).\n\n### Contributing\n\nPlease note [CONTRIBUTING.md](CONTRIBUTING.md).\n\n### License\n\nSplunk Event Generator is licensed under the Apache License 2.0. Details can be found in the [LICENSE](LICENSE) file.\n\n### Support\n\nThis software is released as-is. Splunk provides no warranty and no support on this software.\nIf you have any issues with the software, please read over the [guidelines](http://splunk.github.io/eventgen/FILE_ISSUES.md) and file an issue.\n',
    'author': 'Brian Bingham',
    'author_email': 'bbingham@splunk.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/splunk/eventgen',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
